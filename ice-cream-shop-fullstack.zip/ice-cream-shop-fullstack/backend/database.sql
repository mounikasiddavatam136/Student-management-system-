CREATE DATABASE IF NOT EXISTS icecream_shop;
USE icecream_shop;
CREATE TABLE IF NOT EXISTS ice_creams (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 name VARCHAR(100) NOT NULL,
 flavor VARCHAR(100) NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 available BOOLEAN NOT NULL DEFAULT TRUE
);
INSERT INTO ice_creams(name,flavor,price,available) VALUES
('Classic Vanilla','Vanilla',80,TRUE),
('Chocolate Dream','Chocolate',100,TRUE),
('Strawberry Bliss','Strawberry',90,TRUE),
('Mango Magic','Mango',95,TRUE);
