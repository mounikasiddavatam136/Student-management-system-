package com.icecreamshop.service;
import com.icecreamshop.entity.IceCream;
import com.icecreamshop.repository.IceCreamRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class IceCreamService {
 private final IceCreamRepository repo;
 public IceCreamService(IceCreamRepository repo){this.repo=repo;}
 public List<IceCream> getAll(){return repo.findAll();}
 public IceCream get(Long id){return repo.findById(id).orElseThrow();}
 public IceCream save(IceCream x){return repo.save(x);}
 public IceCream update(Long id,IceCream x){IceCream e=get(id);e.setName(x.getName());e.setFlavor(x.getFlavor());e.setPrice(x.getPrice());e.setAvailable(x.isAvailable());return repo.save(e);}
 public void delete(Long id){repo.deleteById(id);}
}
