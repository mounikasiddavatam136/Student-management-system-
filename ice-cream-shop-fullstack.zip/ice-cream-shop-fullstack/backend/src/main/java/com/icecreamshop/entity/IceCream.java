package com.icecreamshop.entity;
import jakarta.persistence.*;
@Entity
@Table(name="ice_creams")
public class IceCream {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String name;
 private String flavor;
 private double price;
 private boolean available=true;
 public IceCream(){}
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getName(){return name;} public void setName(String v){name=v;}
 public String getFlavor(){return flavor;} public void setFlavor(String v){flavor=v;}
 public double getPrice(){return price;} public void setPrice(double v){price=v;}
 public boolean isAvailable(){return available;} public void setAvailable(boolean v){available=v;}
}
