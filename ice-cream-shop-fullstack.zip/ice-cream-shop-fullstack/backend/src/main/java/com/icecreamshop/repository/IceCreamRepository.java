package com.icecreamshop.repository;
import com.icecreamshop.entity.IceCream;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IceCreamRepository extends JpaRepository<IceCream,Long> {}
