package com.icecreamshop.controller;
import com.icecreamshop.entity.IceCream;
import com.icecreamshop.service.IceCreamService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/icecreams")
@CrossOrigin(origins="*")
public class IceCreamController {
 private final IceCreamService service;
 public IceCreamController(IceCreamService service){this.service=service;}
 @GetMapping public List<IceCream> all(){return service.getAll();}
 @GetMapping("/{id}") public IceCream one(@PathVariable Long id){return service.get(id);}
 @PostMapping public IceCream create(@RequestBody IceCream x){return service.save(x);}
 @PutMapping("/{id}") public IceCream update(@PathVariable Long id,@RequestBody IceCream x){return service.update(id,x);}
 @DeleteMapping("/{id}") public void delete(@PathVariable Long id){service.delete(id);}
}
