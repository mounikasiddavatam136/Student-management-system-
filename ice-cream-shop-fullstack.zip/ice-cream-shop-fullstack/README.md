# Ice Cream Shop Full Stack

Java 17 + Spring Boot + REST API + Spring Data JPA + MySQL + HTML/CSS/JavaScript.

## Run
1. Run backend/database.sql in MySQL.
2. Edit backend/src/main/resources/application.properties with your MySQL password.
3. Open backend in IntelliJ/Eclipse and run IceCreamShopApplication.java.
4. Open frontend/index.html in a browser.

API: http://localhost:8080/api/icecreams
